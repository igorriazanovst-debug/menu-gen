// ── 1. В store/index.ts добавить reducer ────────────────────────────────────
//
// import specialistReducer from "./specialistSlice";
//
// export const store = configureStore({
//   reducer: {
//     ...existingReducers,
//     specialist: specialistReducer,   // <-- добавить
//   },
// });


// ── 2. В App.tsx / router добавить маршруты ─────────────────────────────────
// (внутрь PrivateRoute / Layout как есть в проекте)
//
// import { SpecialistDashboardPage }  from "./pages/specialist/SpecialistDashboardPage";
// import { SpecialistRegisterPage }   from "./pages/specialist/SpecialistRegisterPage";
// import { ClientDetailPage }         from "./pages/specialist/ClientDetailPage";
// import { ClientMenuEditorPage }     from "./pages/specialist/ClientMenuEditorPage";
// import { RecommendationFormPage }   from "./pages/specialist/RecommendationFormPage";
//
// <Route path="/specialist" element={<SpecialistDashboardPage />} />
// <Route path="/specialist/register" element={<SpecialistRegisterPage />} />
// <Route path="/specialist/clients/:familyId" element={<ClientDetailPage />} />
// <Route path="/specialist/clients/:familyId/menus/:menuId" element={<ClientMenuEditorPage />} />
// <Route path="/specialist/clients/:familyId/recommendations/new" element={<RecommendationFormPage />} />


// ── 3. В Sidebar/Nav добавить ссылку ────────────────────────────────────────
// (показывать только если user имеет specialist_profile)
//
// { label: "Кабинет специалиста", path: "/specialist", icon: "medical_services" }
